import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    // Shared fields (doctor + patient)
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },

    role: { type: String, enum: ["patient", "doctor", "admin"], default: "patient" },

    // Patient fields
    age: { type: Number },
    phone: { type: String },
    city: { type: String },

    // Doctor fields
    specialty: { type: String },
    province: { type: String },
    clinicName: { type: String },
    yearsOfExperience: { type: Number },
    registrationNumber: { type: String },

    // Doctor approval status
    status: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" }
  },
  { timestamps: true }
);

export default mongoose.model("User", userSchema);
