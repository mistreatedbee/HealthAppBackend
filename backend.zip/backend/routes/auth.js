import express from "express";
import bcrypt from "bcrypt";
import User from "../models/User.js";

const router = express.Router();

/* REGISTER PATIENT */
router.post("/register", async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;

    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ success: false, message: "Email already registered" });

    const hashed = await bcrypt.hash(password, 10);

    const user = await User.create({
      firstName,
      lastName,
      email,
      password: hashed,
      role: "patient"
    });

    const { password: _, ...safe } = user.toObject();
    res.json({ success: true, user: safe });
  } catch (e) {
    res.status(500).json({ success: false, message: "Patient registration failed" });
  }
});

/* REGISTER DOCTOR */
router.post("/register-doctor", async (req, res) => {
  try {
    const data = req.body;
    const exists = await User.findOne({ email: data.email });
    if (exists) return res.status(400).json({ success: false, message: "Email already registered" });

    const hashed = await bcrypt.hash(data.password, 10);

    const doctor = await User.create({
      ...data,
      password: hashed,
      role: "doctor",
      status: "pending"
    });

    const { password: _, ...safe } = doctor.toObject();
    res.json({ success: true, user: safe });
  } catch (e) {
    res.status(500).json({ success: false, message: "Doctor registration failed" });
  }
});

/* LOGIN */
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ success: false, message: "User not found" });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(400).json({ success: false, message: "Incorrect password" });

    const { password: _, ...safe } = user.toObject();
    res.json({ success: true, user: safe });
  } catch {
    res.status(500).json({ success: false, message: "Login failed" });
  }
});

export default router;
