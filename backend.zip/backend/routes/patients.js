import express from "express";
import User from "../models/User.js";

const router = express.Router();

// Update patient profile
router.put("/:id", async (req, res) => {
  const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!updatedUser) return res.status(404).send("Patient not found");
  res.json(updatedUser);
});

// Delete patient
router.delete("/:id", async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.sendStatus(204);
});

export default router;
